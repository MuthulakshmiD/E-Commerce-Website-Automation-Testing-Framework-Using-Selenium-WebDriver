package com.bank.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

    WebDriver driver;


    By username = By.id("user-name");

    By password = By.id("password");

    By loginButton = By.id("login-button");


    public LoginPage(WebDriver driver){

        this.driver = driver;

    }


    public void login(String user, String pass) throws InterruptedException {


        driver.findElement(username)
                .sendKeys(user);

        // wait after typing username
        Thread.sleep(2000);



        driver.findElement(password)
                .sendKeys(pass);

        // wait after typing password
        Thread.sleep(2000);



        driver.findElement(loginButton)
                .click();

        // wait after login click
        Thread.sleep(5000);

    }

}