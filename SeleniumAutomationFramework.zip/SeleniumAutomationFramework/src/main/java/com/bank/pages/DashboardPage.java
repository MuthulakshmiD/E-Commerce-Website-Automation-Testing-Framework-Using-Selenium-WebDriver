package com.bank.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class DashboardPage {

    WebDriver driver;


    By pageTitle = By.className("title");


    public DashboardPage(WebDriver driver){

        this.driver = driver;

    }


    public String getPageTitle(){

        return driver.findElement(pageTitle)
                .getText();

    }

}