package com.bank.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class BaseTest {

    public WebDriver driver;

    @BeforeMethod
    public void setup() throws InterruptedException {

        driver = new ChromeDriver();

        driver.manage()
                .window()
                .maximize();

        driver.get("https://www.saucedemo.com/");

        // Wait for website opening
        Thread.sleep(3000);
    }


    @AfterMethod
    public void tearDown() throws InterruptedException {

        // Keep browser open for video
        Thread.sleep(5000);

        driver.quit();

    }
}