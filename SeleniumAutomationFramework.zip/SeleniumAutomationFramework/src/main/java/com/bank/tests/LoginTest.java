package com.bank.tests;

import com.bank.base.BaseTest;
import com.bank.pages.DashboardPage;
import com.bank.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginTest extends BaseTest {

    @Test
    public void verifyLogin() throws InterruptedException {

        LoginPage loginPage = new LoginPage(driver);

        loginPage.login(
                "standard_user",
                "secret_sauce"
        );

        DashboardPage dashboard = new DashboardPage(driver);

        String title = dashboard.getPageTitle();

        Assert.assertEquals(
                title,
                "Products"
        );

        System.out.println(
                "Login Successful - Dashboard Verified"
        );

    }

}